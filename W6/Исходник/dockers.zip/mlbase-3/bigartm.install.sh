#!/bin/bash

# the Pip version for target Python
PIP=pip3
CUR_DIR=$(dirname "$0")

sudo rm -rf $CUR_DIR/bigartm && sudo apt-get --yes install git make cmake build-essential libboost-all-dev && \
git clone --branch=stable https://github.com/bigartm/bigartm.git $CUR_DIR/bigartm && \
cd $CUR_DIR/bigartm && \
mkdir build && cd build && \
cmake .. && \
make && \
sudo make install && \
export ARTM_SHARED_LIBRARY=/usr/local/lib/libartm.so && \
sudo $PIP install python/bigartm*.whl &&
sudo $PIP install --upgrade google-api-python-client &&
sudo $PIP install protobuf