#!/bin/bash

NAME="mlbase-3"

docker build --no-cache -f ./Dockerfile -t $NAME .
#docker build -f ./Dockerfile -t $NAME .
