#!/bin/bash

MLBASE_NAME="mlbase-3"

#docker run --rm -it --name $NAME $NAME /bin/bash

docker run --rm -it -p $MLBASE_PORT:$MLBASE_PORT -v $MLBASE_ROOT:$MLBASE_ROOT --name $MLBASE_NAME $MLBASE_NAME \
	sh -c \
	"cd $MLBASE_ROOT && jupyter notebook --ip=0.0.0.0 --port=$MLBASE_PORT --no-browser --allow-root --NotebookApp.token='' --NotebookApp.password=''"	
