#!/bin/bash

MLBASE_NAME="mlbase"

#docker run --rm -it --name $NAME $NAME /bin/bash

docker run --rm -it -v $MLBASE_ROOT:$MLBASE_ROOT --name $MLBASE_NAME $MLBASE_NAME
