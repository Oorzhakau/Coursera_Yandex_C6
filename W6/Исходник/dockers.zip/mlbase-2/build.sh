#!/bin/bash

NAME="mlbase"

docker build --no-cache -f ./Dockerfile -t $NAME .
#docker build -f ./Dockerfile -t $NAME .
